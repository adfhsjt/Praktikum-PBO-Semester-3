/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author ahmad
 */
public class DemoHp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        HandPhone hp1 = new HandPhone("123", "Flip", "12.5");
        hp1.tambahVolume();
        
        hp1.power();
        
        hp1.tambahVolume();
        hp1.info();
        
        hp1.mute();
        hp1.info();
        
        hp1.mute();
        hp1.info();
        
        
//        for(int i = 0; i< 20; i++){
//            hp1.tambahVolume();
//        }
//        hp1.tambahVolume();
//        
//        for(int j = 0; j < 20; j++){
//            hp1.kurangiVolume();
//        }
//        hp1.kurangiVolume();
//        
        
        
//        hp1.tambahVolume();
//        hp1.tambahVolume();
//        hp1.tambahVolume();
//        hp1.tambahVolume();
//        hp1.tambahVolume();
//        hp1.tambahVolume();
//        hp1.info();
//        
//        hp1.kurangiVolume();
//        hp1.kurangiVolume();
//        hp1.kurangiVolume();
//        hp1.kurangiVolume();
//        hp1.info();
//        
//        hp1.mute();
//        hp1.info();
//        
//        hp1.mute();
//        hp1.info();
//        
//        hp1.off();
//        hp1.info();
    }
    
}
